# 19ucc023
# Mohit Akhouri
# IDS Assignment 1

# using Box muller method to generate Gaussian Random variable
from numpy import *
import matplotlib.pyplot as plt
U1 = random.uniform(size = 10000)
U2 = random.uniform(size = 10000)
Z1 = (sqrt(-2*log(U1)))*cos(2*pi*U2)
Z2 = (sqrt(-2*log(U1)))*sin(2*pi*U2)

fig,(as1,as2) = plt.subplots(1,2)
as1.hist(Z1)
as1.set_title('Z1 (0,1)')
as2.hist(Z2)
as2.set_title('Z2 (0,1)')
plt.show()

