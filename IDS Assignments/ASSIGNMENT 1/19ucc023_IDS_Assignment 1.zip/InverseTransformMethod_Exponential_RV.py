# 19ucc023
# Mohit Akhouri
# IDS Assignment 1

# using inverse transform method to generate Exponential Random variable
import matplotlib.pyplot as plt
from math import log
m = 2**64-1
a = 265641321
c = 123845325
Xo = 0.34578
U = []
bins =[]
length = 1000000
U.append(Xo)
for n in range(1,length+1):
    Xn = (a * U[n-1] + c) % m
    Xn = Xn/m
    U.append(Xn)

# generating exponential random numbers
X = []
lmd = 0.5
for i in range(1,length):
    Xn = (-1/lmd)*(log(1-U[i]))
    X.append(Xn)

plt.hist(X)
plt.xlabel('exponential random numbers->')
plt.ylabel('frequency->')
plt.title('exponentially generated random number via Inverse transform method')
plt.show()
