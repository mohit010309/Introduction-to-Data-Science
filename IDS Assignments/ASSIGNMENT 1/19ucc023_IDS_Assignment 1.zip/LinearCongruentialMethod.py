# 19ucc023
# Mohit Akhouri
# IDS Assignment 1

# linear congruential method to generate uniform random variable
import matplotlib.pyplot as plt
m = 2**64-1
a = 265641321
c = 123845325
Xo = 0.34578
X = []
length = 1000000
X.append(Xo)
for n in range(1,length+1):
    Xn = (a * X[n-1] + c) % m
    Xn = Xn/m
    X.append(Xn)

plt.hist(X)
plt.xlabel('random variable (U[0,1]) ->')
plt.ylabel('frequency ->')
plt.title('U[0,1] generated using Linear congruential method')
plt.show()
