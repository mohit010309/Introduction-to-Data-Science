# 19ucc023
# Mohit Akhouri
# IDS Assignment 1

# using inverse transform method to generate Cauchy Random variable
import matplotlib.pyplot as plt
from math import tan,pi
m = 2**64-1
a = 265641321
c = 123845325
Xo = 0.34578
U = []
bins =[]
length = 1000000
U.append(Xo)
for n in range(1,length+1):
    Xn = (a * U[n-1] + c) % m
    Xn = Xn/m
    U.append(Xn)

# generating Cauchy Random variable
X = []
for i in range(0,length):
    Xn = tan(pi * (U[i]-0.5))
    X.append(Xn)

plt.hist(X)
plt.xlabel('Cauchy random numbers->')
plt.ylabel('frequency->')
plt.title('Cauchy distributed generated random number via Inverse transform method')
plt.show()